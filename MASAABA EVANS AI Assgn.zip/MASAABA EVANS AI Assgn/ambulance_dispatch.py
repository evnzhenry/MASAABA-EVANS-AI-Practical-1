import heapq
import math


city_map = {
    'A': [('B', 2), ('C', 5)],
    'B': [('A', 2), ('D', 4)],
    'C': [('A', 5), ('D', 2), ('E', 3)],
    'D': [('B', 4), ('C', 2), ('F', 1)],
    'E': [('C', 3), ('F', 2)],
    'F': [('D', 1), ('E', 2)]
}


coords = {
    'A': (0, 0),
    'B': (2, 0),
    'C': (0, 3),
    'D': (2, 3),
    'E': (0, 6),
    'F': (2, 6)
}

def heuristic(a, b):
    (x1, y1), (x2, y2) = coords[a], coords[b]
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

def a_star_search(graph, start, goal):
    pq = [(0, start)]
    g = {start: 0}
    parent = {start: None}

    while pq:
        f, node = heapq.heappop(pq)
        if node == goal:
            path = []
            while node:
                path.append(node)
                node = parent[node]
            return path[::-1], g[goal]

        for neighbor, cost in graph[node]:
            new_g = g[node] + cost
            if neighbor not in g or new_g < g[neighbor]:
                g[neighbor] = new_g
                f = new_g + heuristic(neighbor, goal)
                heapq.heappush(pq, (f, neighbor))
                parent[neighbor] = node
    return None, float('inf')


path, cost = a_star_search(city_map, 'A', 'F')
print("Ambulance Path:", path)
print("Total Cost (time):", cost)
