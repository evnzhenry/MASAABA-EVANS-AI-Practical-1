from collections import deque

maze = [
    [0, 0, 1, 0, 0],
    [1, 0, 1, 0, 1],
    [0, 0, 0, 0, 0],
    [0, 1, 1, 1, 0],
    [0, 0, 0, 1, 0]
]

n = len(maze)
start = (0, 0)  
goal = (4, 4)   


visited = []
queue = deque()   
parent = {}  


def get_neighbors(node):
    (x, y) = node
    neighbors = []
    moves = [(-1,0), (1,0), (0,-1), (0,1)] 
    for dx, dy in moves:
        nx, ny = x+dx, y+dy
        if 0 <= nx < n and 0 <= ny < n and maze[nx][ny] == 0:
            neighbors.append((nx, ny))
    return neighbors


def bfs(start):
    visited.append(start)
    queue.append(start)

    while queue:
        s = queue.popleft()  
        print("Visiting:", s)

        if s == goal:
            print("Goal reached:", s)
            return True

        for neighbour in get_neighbors(s):
            if neighbour not in visited:
                visited.append(neighbour)
                parent[neighbour] = s
                queue.append(neighbour)
    return False


found = bfs(start)


if found:
    path = []
    cur = goal
    while cur != start:
        path.append(cur)
        cur = parent[cur]
    path.append(start)
    path.reverse()
    print("\nShortest Path (BFS):", path)
else:
    print("No path found.")

